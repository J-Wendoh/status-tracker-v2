import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Mail, Shield, ArrowLeft } from 'lucide-react'

export default function CheckEmailPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 flex items-center justify-center p-4">
      {/* Kenya flag subtle background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-1/4 bg-black"></div>
        <div className="absolute top-1/4 left-0 w-full h-1/4 bg-red-600"></div>
        <div className="absolute top-2/4 left-0 w-full h-1/4 bg-green-600"></div>
        <div className="absolute top-3/4 left-0 w-full h-1/4 bg-white"></div>
      </div>

      <Card className="w-full max-w-md relative z-10 government-card border-oag-primary/20">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <Mail className="h-8 w-8 text-green-600" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Check your email
            </CardTitle>
            <CardDescription className="text-gray-600 mt-2">
              We've sent you a confirmation link to complete your registration
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6 text-center">
          <div className="space-y-3">
            <p className="text-gray-700">
              Please check your email inbox and click the confirmation link to activate your OAG account.
            </p>
            <p className="text-sm text-gray-600">
              The confirmation email may take a few minutes to arrive. Don't forget to check your spam folder.
            </p>
          </div>

          <div className="pt-4 border-t">
            <Link href="/auth/login">
              <Button 
                variant="outline" 
                className="w-full border-oag-primary/30 text-oag-primary hover:bg-oag-primary/5"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Sign In
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}