"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Shield, Mail, User, MapPin, Building, Lock } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { KENYAN_COUNTIES } from '@/lib/constants'

interface DepartmentSaga {
  id: string
  name: string
  type: 'Department' | 'SAGA'
}

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    email: '',
    fullName: '',
    county: '',
    category: '',
    departmentSagaId: '',
    password: '',
    confirmPassword: ''
  })
  const [departments, setDepartments] = useState<DepartmentSaga[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    fetchDepartments()
  }, [])

  const fetchDepartments = async () => {
    try {
      const { data, error } = await supabase
        .from('departments_sagas')
        .select('*')
        .order('name')

      if (error) throw error
      setDepartments(data || [])
    } catch (error) {
      console.error('Error fetching departments:', error)
    }
  }

  const getFilteredDepartments = () => {
    if (!formData.category) return []
    return departments.filter(dept => 
      (formData.category === 'Department' && dept.type === 'Department') ||
      (formData.category === 'SAGA' && dept.type === 'SAGA')
    )
  }

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      // Reset department when category changes
      ...(field === 'category' ? { departmentSagaId: '' } : {})
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match')
      setLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters long')
      setLoading(false)
      return
    }

    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password
      })

      if (authError) throw authError

      if (authData.user) {
        // Create user profile
        const { error: profileError } = await supabase
          .from('users')
          .insert({
            id: authData.user.id,
            email: formData.email,
            full_name: formData.fullName,
            county: formData.county,
            category: formData.category as any,
            department_saga_id: formData.departmentSagaId
          })

        if (profileError) throw profileError

        router.push('/auth/check-email')
      }
    } catch (error: any) {
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-orange-50 to-amber-100 flex items-center justify-center p-4">
      {/* Kenya flag subtle background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-1/4 bg-black"></div>
        <div className="absolute top-1/4 left-0 w-full h-1/4 bg-red-600"></div>
        <div className="absolute top-2/4 left-0 w-full h-1/4 bg-green-600"></div>
        <div className="absolute top-3/4 left-0 w-full h-1/4 bg-white"></div>
      </div>

      <Card className="w-full max-w-lg relative z-10 government-card border-oag-primary/20">
        <CardHeader className="space-y-4 text-center">
          <div className="mx-auto w-16 h-16 oag-gradient rounded-full flex items-center justify-center">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl font-bold text-gray-900">
              Register for OAG System
            </CardTitle>
            <CardDescription className="text-gray-600 mt-2">
              Office of the Attorney General - Kenya
              <br />
              Create your account to access the activity logging system
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="email" className="text-gray-700 font-medium">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@oag.go.ke"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    className="pl-10 border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
                    required
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="fullName" className="text-gray-700 font-medium">
                  Full Name
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="John Doe"
                    value={formData.fullName}
                    onChange={(e) => handleChange('fullName', e.target.value)}
                    className="pl-10 border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
                    required
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-700 font-medium">County</Label>
                <Select
                  value={formData.county}
                  onValueChange={(value) => handleChange('county', value)}
                  disabled={loading}
                >
                  <SelectTrigger className="border-gray-300 focus:border-oag-primary focus:ring-oag-primary">
                    <SelectValue placeholder="Select county" />
                  </SelectTrigger>
                  <SelectContent>
                    {KENYAN_COUNTIES.map((county) => (
                      <SelectItem key={county} value={county}>
                        {county}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-700 font-medium">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => handleChange('category', value)}
                  disabled={loading}
                >
                  <SelectTrigger className="border-gray-300 focus:border-oag-primary focus:ring-oag-primary">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Department">Department</SelectItem>
                    <SelectItem value="SAGA">SAGA</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label className="text-gray-700 font-medium">
                  {formData.category === 'Department' ? 'Department' : 'SAGA'}
                </Label>
                <Select
                  value={formData.departmentSagaId}
                  onValueChange={(value) => handleChange('departmentSagaId', value)}
                  disabled={loading || !formData.category}
                >
                  <SelectTrigger className="border-gray-300 focus:border-oag-primary focus:ring-oag-primary">
                    <SelectValue placeholder={`Select ${formData.category || 'category first'}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {getFilteredDepartments().map((dept) => (
                      <SelectItem key={dept.id} value={dept.id}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700 font-medium">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => handleChange('password', e.target.value)}
                    className="pl-10 border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
                    required
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-gray-700 font-medium">
                  Confirm Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    id="confirmPassword"
                    type="password"
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => handleChange('confirmPassword', e.target.value)}
                    className="pl-10 border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
                    required
                    disabled={loading}
                  />
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-oag-primary hover:bg-oag-secondary text-white font-medium py-2.5 transition-colors"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating account...
                </>
              ) : (
                'Register'
              )}
            </Button>

            <div className="text-center text-sm">
              <span className="text-gray-600">Already have an account? </span>
              <Link 
                href="/auth/login" 
                className="text-oag-primary hover:text-oag-secondary font-medium hover:underline"
              >
                Sign in here
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}