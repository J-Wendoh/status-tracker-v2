"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Navigation } from '@/components/ui/navigation'
import { Plus, Activity, Clock, CheckCircle, AlertCircle } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { ActivitySubmissionDialog } from '@/components/activity-submission-dialog'

interface UserProfile {
  id: string
  email: string
  full_name: string
  category: string
  department: {
    id: string
    name: string
    type: string
  }
}

interface Service {
  id: string
  name: string
  description: string
}

interface ActivityWithStatus {
  id: string
  description: string
  challenges: string | null
  created_at: string
  service: {
    name: string
  }
  activity_status: {
    pending_count: number
    completed_count: number
  }[]
}

export default function OfficerDashboard() {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [services, setServices] = useState<Service[]>([])
  const [activities, setActivities] = useState<ActivityWithStatus[]>([])
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    completed: 0
  })
  const [loading, setLoading] = useState(true)
  const [showSubmissionDialog, setShowSubmissionDialog] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkAuthAndLoadData()
  }, [])

  const checkAuthAndLoadData = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser()
    
    if (!authUser) {
      router.push('/auth/login')
      return
    }

    try {
      // Get user profile with department
      const { data: profile, error: profileError } = await supabase
        .from('users')
        .select(`
          id,
          email,
          full_name,
          category,
          departments_sagas:department_saga_id (
            id,
            name,
            type
          )
        `)
        .eq('id', authUser.id)
        .single()

      if (profileError) throw profileError

      const userProfile = {
        ...profile,
        department: profile.departments_sagas
      }
      setUser(userProfile)

      // Load services for this department
      const { data: servicesData, error: servicesError } = await supabase
        .from('services')
        .select('*')
        .eq('department_saga_id', profile.departments_sagas.id)
        .order('name')

      if (servicesError) throw servicesError
      setServices(servicesData || [])

      // Load user's activities with status
      const { data: activitiesData, error: activitiesError } = await supabase
        .from('activities')
        .select(`
          id,
          description,
          challenges,
          created_at,
          services:service_id (
            name
          ),
          activity_status (
            pending_count,
            completed_count
          )
        `)
        .eq('user_id', authUser.id)
        .order('created_at', { ascending: false })

      if (activitiesError) throw activitiesError
      
      const formattedActivities = activitiesData?.map(activity => ({
        ...activity,
        service: activity.services,
        activity_status: activity.activity_status || []
      })) || []

      setActivities(formattedActivities)

      // Calculate stats
      const total = formattedActivities.length
      let pending = 0
      let completed = 0

      formattedActivities.forEach(activity => {
        const latestStatus = activity.activity_status[activity.activity_status.length - 1]
        if (latestStatus) {
          pending += latestStatus.pending_count
          completed += latestStatus.completed_count
        }
      })

      setStats({ total, pending, completed })

    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleActivitySubmitted = () => {
    setShowSubmissionDialog(false)
    checkAuthAndLoadData() // Reload data
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-oag-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="government-header rounded-lg p-6 text-white">
            <h1 className="text-3xl font-bold mb-2">Welcome, {user.full_name}</h1>
            <p className="text-orange-100">
              {user.category} • {user.department.name}
            </p>
            <p className="text-orange-200 text-sm">
              Track and submit your daily activities below
            </p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="government-card border-blue-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Activities
                </CardTitle>
                <Activity className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <p className="text-xs text-gray-500">All time submissions</p>
            </CardContent>
          </Card>

          <Card className="government-card border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Pending Tasks
                </CardTitle>
                <Clock className="h-4 w-4 text-orange-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.pending}</div>
              <p className="text-xs text-gray-500">Awaiting completion</p>
            </CardContent>
          </Card>

          <Card className="government-card border-green-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Completed Tasks
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
              <p className="text-xs text-gray-500">Successfully finished</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Activity Submission */}
          <div className="lg:col-span-2">
            <Card className="government-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl text-gray-900">Recent Activities</CardTitle>
                    <CardDescription>
                      Your latest activity submissions and their status
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowSubmissionDialog(true)}
                    className="bg-oag-primary hover:bg-oag-secondary text-white"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    New Activity
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activities.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No activities submitted yet</p>
                      <p className="text-sm">Click "New Activity" to get started</p>
                    </div>
                  ) : (
                    activities.slice(0, 5).map((activity) => {
                      const latestStatus = activity.activity_status[activity.activity_status.length - 1]
                      const hasPending = latestStatus?.pending_count > 0
                      const hasCompleted = latestStatus?.completed_count > 0

                      return (
                        <div key={activity.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h4 className="font-medium text-gray-900 line-clamp-2">
                                  {activity.description}
                                </h4>
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                                <span>Service: {activity.service.name}</span>
                                <span>•</span>
                                <span>{new Date(activity.created_at).toLocaleDateString()}</span>
                              </div>
                              {activity.challenges && (
                                <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded mt-2">
                                  <span className="font-medium">Challenges:</span> {activity.challenges}
                                </p>
                              )}
                            </div>
                            <div className="flex flex-col gap-1 ml-4">
                              {hasPending && (
                                <Badge variant="outline" className="text-orange-600 border-orange-600">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {latestStatus.pending_count} pending
                                </Badge>
                              )}
                              {hasCompleted && (
                                <Badge variant="outline" className="text-green-600 border-green-600">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  {latestStatus.completed_count} completed
                                </Badge>
                              )}
                              {!hasPending && !hasCompleted && (
                                <Badge variant="outline" className="text-gray-600 border-gray-600">
                                  <AlertCircle className="h-3 w-3 mr-1" />
                                  No status
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Services List */}
          <div>
            <Card className="government-card">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Department Services</CardTitle>
                <CardDescription>
                  Available services for {user.department.name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {services.length === 0 ? (
                    <div className="text-center py-4 text-gray-500">
                      <p>No services available</p>
                    </div>
                  ) : (
                    services.map((service) => (
                      <div key={service.id} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                        <h4 className="font-medium text-gray-900">{service.name}</h4>
                        <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <ActivitySubmissionDialog
        open={showSubmissionDialog}
        onOpenChange={setShowSubmissionDialog}
        services={services}
        userId={user.id}
        onSubmitted={handleActivitySubmitted}
      />
    </div>
  )
}