"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/ui/navigation'
import { Users, Activity, Clock, CheckCircle, AlertCircle, Eye, Edit } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { ActivityReviewDialog } from '@/components/activity-review-dialog'

interface UserProfile {
  id: string
  email: string
  full_name: string
  category: string
  department: {
    id: string
    name: string
    type: string
  }
}

interface OfficerActivity {
  id: string
  description: string
  challenges: string | null
  created_at: string
  user: {
    full_name: string
    email: string
  }
  service: {
    name: string
    description: string
  }
  activity_status: {
    id: string
    pending_count: number
    completed_count: number
    updated_by: string
    created_at: string
  }[]
}

interface Officer {
  id: string
  full_name: string
  email: string
  activity_count: number
}

export default function HODDashboard() {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [activities, setActivities] = useState<OfficerActivity[]>([])
  const [officers, setOfficers] = useState<Officer[]>([])
  const [stats, setStats] = useState({
    totalActivities: 0,
    pendingReviews: 0,
    totalOfficers: 0,
    completedTasks: 0
  })
  const [loading, setLoading] = useState(true)
  const [selectedActivity, setSelectedActivity] = useState<OfficerActivity | null>(null)
  const [showReviewDialog, setShowReviewDialog] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkAuthAndLoadData()
  }, [])

  const checkAuthAndLoadData = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser()
    
    if (!authUser) {
      router.push('/auth/login')
      return
    }

    try {
      // Get user profile with department
      const { data: profile, error: profileError } = await supabase
        .from('users')
        .select(`
          id,
          email,
          full_name,
          category,
          departments_sagas:department_saga_id (
            id,
            name,
            type
          )
        `)
        .eq('id', authUser.id)
        .single()

      if (profileError) throw profileError

      const userProfile = {
        ...profile,
        department: profile.departments_sagas
      }
      setUser(userProfile)

      // Load all activities from this department
      const { data: activitiesData, error: activitiesError } = await supabase
        .from('activities')
        .select(`
          id,
          description,
          challenges,
          created_at,
          users:user_id (
            full_name,
            email
          ),
          services:service_id (
            name,
            description,
            department_saga_id
          ),
          activity_status (
            id,
            pending_count,
            completed_count,
            updated_by,
            created_at
          )
        `)
        .eq('services.department_saga_id', profile.departments_sagas.id)
        .order('created_at', { ascending: false })

      if (activitiesError) throw activitiesError

      const formattedActivities = activitiesData?.map(activity => ({
        ...activity,
        user: activity.users,
        service: activity.services,
        activity_status: activity.activity_status || []
      })).filter(activity => activity.service?.department_saga_id === profile.departments_sagas.id) || []

      setActivities(formattedActivities)

      // Load department officers
      const { data: officersData, error: officersError } = await supabase
        .from('users')
        .select(`
          id,
          full_name,
          email,
          activities (count)
        `)
        .eq('department_saga_id', profile.departments_sagas.id)
        .eq('category', 'Officer')

      if (officersError) throw officersError

      const formattedOfficers = officersData?.map(officer => ({
        ...officer,
        activity_count: officer.activities?.[0]?.count || 0
      })) || []

      setOfficers(formattedOfficers)

      // Calculate stats
      const totalActivities = formattedActivities.length
      const pendingReviews = formattedActivities.filter(activity => 
        activity.activity_status.length === 0
      ).length
      const totalOfficers = formattedOfficers.length
      const completedTasks = formattedActivities.reduce((sum, activity) => {
        const latestStatus = activity.activity_status[activity.activity_status.length - 1]
        return sum + (latestStatus?.completed_count || 0)
      }, 0)

      setStats({
        totalActivities,
        pendingReviews,
        totalOfficers,
        completedTasks
      })

    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleReviewActivity = (activity: OfficerActivity) => {
    setSelectedActivity(activity)
    setShowReviewDialog(true)
  }

  const handleReviewSubmitted = () => {
    setShowReviewDialog(false)
    setSelectedActivity(null)
    checkAuthAndLoadData() // Reload data
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-oag-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="government-header rounded-lg p-6 text-white">
            <h1 className="text-3xl font-bold mb-2">Department Head Dashboard</h1>
            <p className="text-orange-100">
              {user.full_name} • {user.department.name}
            </p>
            <p className="text-orange-200 text-sm">
              Review and manage your department's activities and officers
            </p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="government-card border-blue-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Activities
                </CardTitle>
                <Activity className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{stats.totalActivities}</div>
              <p className="text-xs text-gray-500">Department submissions</p>
            </CardContent>
          </Card>

          <Card className="government-card border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Pending Reviews
                </CardTitle>
                <AlertCircle className="h-4 w-4 text-orange-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{stats.pendingReviews}</div>
              <p className="text-xs text-gray-500">Need your attention</p>
            </CardContent>
          </Card>

          <Card className="government-card border-purple-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Officers
                </CardTitle>
                <Users className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{stats.totalOfficers}</div>
              <p className="text-xs text-gray-500">In your department</p>
            </CardContent>
          </Card>

          <Card className="government-card border-green-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Completed Tasks
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{stats.completedTasks}</div>
              <p className="text-xs text-gray-500">Successfully finished</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="activities" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="activities" className="data-[state=active]:bg-oag-primary data-[state=active]:text-white">
              Activities Review
            </TabsTrigger>
            <TabsTrigger value="officers" className="data-[state=active]:bg-oag-primary data-[state=active]:text-white">
              Officers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="activities">
            <Card className="government-card">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Department Activities</CardTitle>
                <CardDescription>
                  Review and update status for activities submitted by your officers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activities.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No activities found</p>
                    </div>
                  ) : (
                    activities.map((activity) => {
                      const latestStatus = activity.activity_status[activity.activity_status.length - 1]
                      const needsReview = !latestStatus
                      const hasPending = latestStatus?.pending_count > 0
                      const hasCompleted = latestStatus?.completed_count > 0

                      return (
                        <div key={activity.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h4 className="font-medium text-gray-900">
                                  {activity.description}
                                </h4>
                                {needsReview && (
                                  <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                                    Needs Review
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                                <span>Officer: {activity.user.full_name}</span>
                                <span>•</span>
                                <span>Service: {activity.service.name}</span>
                                <span>•</span>
                                <span>{new Date(activity.created_at).toLocaleDateString()}</span>
                              </div>
                              {activity.challenges && (
                                <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded mt-2">
                                  <span className="font-medium">Challenges:</span> {activity.challenges}
                                </p>
                              )}
                              {latestStatus && (
                                <div className="flex items-center gap-2 mt-2">
                                  {hasPending && (
                                    <Badge variant="outline" className="text-orange-600 border-orange-600">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {latestStatus.pending_count} pending
                                    </Badge>
                                  )}
                                  {hasCompleted && (
                                    <Badge variant="outline" className="text-green-600 border-green-600">
                                      <CheckCircle className="h-3 w-3 mr-1" />
                                      {latestStatus.completed_count} completed
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2 ml-4">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleReviewActivity(activity)}
                                className="text-oag-primary border-oag-primary hover:bg-oag-primary hover:text-white"
                              >
                                <Edit className="h-4 w-4 mr-1" />
                                Review
                              </Button>
                            </div>
                          </div>
                        </div>
                      )
                    })
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="officers">
            <Card className="government-card">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">Department Officers</CardTitle>
                <CardDescription>
                  All officers in your department and their activity counts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {officers.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p>No officers found</p>
                    </div>
                  ) : (
                    officers.map((officer) => (
                      <div key={officer.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium text-gray-900">{officer.full_name}</h4>
                            <p className="text-sm text-gray-600">{officer.email}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-semibold text-gray-900">
                              {officer.activity_count}
                            </div>
                            <p className="text-xs text-gray-500">activities</p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {selectedActivity && (
        <ActivityReviewDialog
          open={showReviewDialog}
          onOpenChange={setShowReviewDialog}
          activity={selectedActivity}
          reviewerId={user.id}
          onReviewSubmitted={handleReviewSubmitted}
        />
      )}
    </div>
  )
}