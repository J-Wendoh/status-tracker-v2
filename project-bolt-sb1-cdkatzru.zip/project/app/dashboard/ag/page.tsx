"use client"

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/ui/navigation'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Shield, Building, Users, Activity, Clock, CheckCircle, 
  BarChart3, TrendingUp, Calendar, FileText 
} from 'lucide-react'
import { supabase } from '@/lib/supabase'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts'

interface UserProfile {
  id: string
  email: string
  full_name: string
  category: string
}

interface DepartmentStats {
  id: string
  name: string
  type: string
  officer_count: number
  activity_count: number
  pending_count: number
  completed_count: number
}

interface SystemStats {
  total_departments: number
  total_officers: number
  total_activities: number
  pending_tasks: number
  completed_tasks: number
}

const COLORS = ['#F97316', '#DC2626', '#059669', '#3B82F6', '#8B5CF6', '#EC4899']

export default function AGDashboard() {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [systemStats, setSystemStats] = useState<SystemStats>({
    total_departments: 0,
    total_officers: 0,
    total_activities: 0,
    pending_tasks: 0,
    completed_tasks: 0
  })
  const [departmentStats, setDepartmentStats] = useState<DepartmentStats[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTimeframe, setSelectedTimeframe] = useState('all')
  const router = useRouter()

  useEffect(() => {
    checkAuthAndLoadData()
  }, [selectedTimeframe])

  const checkAuthAndLoadData = async () => {
    const { data: { user: authUser } } = await supabase.auth.getUser()
    
    if (!authUser) {
      router.push('/auth/login')
      return
    }

    try {
      // Get user profile
      const { data: profile, error: profileError } = await supabase
        .from('users')
        .select('id, email, full_name, category')
        .eq('id', authUser.id)
        .single()

      if (profileError) throw profileError
      setUser(profile)

      // Verify AG access
      if (profile.category !== 'AG') {
        router.push('/dashboard')
        return
      }

      // Load system statistics
      await Promise.all([
        loadSystemStats(),
        loadDepartmentStats()
      ])

    } catch (error) {
      console.error('Error loading data:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadSystemStats = async () => {
    try {
      // Get department count
      const { count: deptCount } = await supabase
        .from('departments_sagas')
        .select('*', { count: 'exact' })

      // Get officer count
      const { count: officerCount } = await supabase
        .from('users')
        .select('*', { count: 'exact' })
        .eq('category', 'Officer')

      // Get activity count
      const { count: activityCount } = await supabase
        .from('activities')
        .select('*', { count: 'exact' })

      // Get task counts from activity_status
      const { data: statusData } = await supabase
        .from('activity_status')
        .select('pending_count, completed_count')

      let pendingTasks = 0
      let completedTasks = 0

      statusData?.forEach(status => {
        pendingTasks += status.pending_count
        completedTasks += status.completed_count
      })

      setSystemStats({
        total_departments: deptCount || 0,
        total_officers: officerCount || 0,
        total_activities: activityCount || 0,
        pending_tasks: pendingTasks,
        completed_tasks: completedTasks
      })

    } catch (error) {
      console.error('Error loading system stats:', error)
    }
  }

  const loadDepartmentStats = async () => {
    try {
      // Get departments with their stats
      const { data: departments } = await supabase
        .from('departments_sagas')
        .select('id, name, type')
        .order('name')

      if (!departments) return

      const departmentStatsPromises = departments.map(async (dept) => {
        // Get officer count for this department
        const { count: officerCount } = await supabase
          .from('users')
          .select('*', { count: 'exact' })
          .eq('department_saga_id', dept.id)
          .eq('category', 'Officer')

        // Get activities for this department through services
        const { data: activities } = await supabase
          .from('activities')
          .select(`
            id,
            activity_status (
              pending_count,
              completed_count
            )
          `)
          .in('service_id', 
            await supabase
              .from('services')
              .select('id')
              .eq('department_saga_id', dept.id)
              .then(({ data }) => data?.map(s => s.id) || [])
          )

        let activityCount = activities?.length || 0
        let pendingCount = 0
        let completedCount = 0

        activities?.forEach(activity => {
          activity.activity_status?.forEach(status => {
            pendingCount += status.pending_count
            completedCount += status.completed_count
          })
        })

        return {
          ...dept,
          officer_count: officerCount || 0,
          activity_count: activityCount,
          pending_count: pendingCount,
          completed_count: completedCount
        }
      })

      const stats = await Promise.all(departmentStatsPromises)
      setDepartmentStats(stats)

    } catch (error) {
      console.error('Error loading department stats:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-oag-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Loading AG dashboard...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const chartData = departmentStats.map(dept => ({
    name: dept.name.substring(0, 15) + (dept.name.length > 15 ? '...' : ''),
    activities: dept.activity_count,
    officers: dept.officer_count,
    pending: dept.pending_count,
    completed: dept.completed_count
  }))

  const typeData = [
    { name: 'Departments', value: departmentStats.filter(d => d.type === 'Department').length },
    { name: 'SAGAs', value: departmentStats.filter(d => d.type === 'SAGA').length }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation user={user} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* AG Header */}
        <div className="mb-8">
          <div className="government-header rounded-lg p-6 text-white relative overflow-hidden">
            <div className="absolute inset-0 kenya-flag-subtle"></div>
            <div className="relative z-10">
              <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
                <Shield className="h-8 w-8" />
                Attorney General Dashboard
              </h1>
              <p className="text-orange-100">
                {user.full_name} • System-wide Overview
              </p>
              <p className="text-orange-200 text-sm">
                Monitor all departments, SAGAs, and activity performance across the OAG system
              </p>
            </div>
          </div>
        </div>

        {/* System Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className="government-card border-blue-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Departments & SAGAs
                </CardTitle>
                <Building className="h-4 w-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-900">{systemStats.total_departments}</div>
              <p className="text-xs text-gray-500">Total entities</p>
            </CardContent>
          </Card>

          <Card className="government-card border-purple-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Officers
                </CardTitle>
                <Users className="h-4 w-4 text-purple-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{systemStats.total_officers}</div>
              <p className="text-xs text-gray-500">System-wide</p>
            </CardContent>
          </Card>

          <Card className="government-card border-green-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Total Activities
                </CardTitle>
                <Activity className="h-4 w-4 text-green-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{systemStats.total_activities}</div>
              <p className="text-xs text-gray-500">Submitted</p>
            </CardContent>
          </Card>

          <Card className="government-card border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Pending Tasks
                </CardTitle>
                <Clock className="h-4 w-4 text-orange-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{systemStats.pending_tasks}</div>
              <p className="text-xs text-gray-500">In progress</p>
            </CardContent>
          </Card>

          <Card className="government-card border-emerald-200">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-gray-600">
                  Completed Tasks
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-emerald-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">{systemStats.completed_tasks}</div>
              <p className="text-xs text-gray-500">Finished</p>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Section */}
        <Tabs defaultValue="departments" className="space-y-6">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-fit grid-cols-3">
              <TabsTrigger value="departments" className="data-[state=active]:bg-oag-primary data-[state=active]:text-white">
                Department Analysis
              </TabsTrigger>
              <TabsTrigger value="performance" className="data-[state=active]:bg-oag-primary data-[state=active]:text-white">
                Performance Metrics
              </TabsTrigger>
              <TabsTrigger value="overview" className="data-[state=active]:bg-oag-primary data-[state=active]:text-white">
                System Overview
              </TabsTrigger>
            </TabsList>

            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <TabsContent value="departments" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="government-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-oag-primary" />
                    Activity Distribution by Department
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="activities" fill="#F97316" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="government-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building className="h-5 w-5 text-oag-primary" />
                    Department vs SAGA Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={typeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {typeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Department Details Table */}
            <Card className="government-card">
              <CardHeader>
                <CardTitle>Department Performance Details</CardTitle>
                <CardDescription>
                  Comprehensive view of all departments and their key metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {departmentStats.map((dept) => (
                    <div key={dept.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium text-gray-900">{dept.name}</h4>
                            <Badge variant={dept.type === 'Department' ? 'default' : 'secondary'}>
                              {dept.type}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Officers:</span>
                              <span className="ml-1 font-medium">{dept.officer_count}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Activities:</span>
                              <span className="ml-1 font-medium">{dept.activity_count}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Pending:</span>
                              <span className="ml-1 font-medium text-orange-600">{dept.pending_count}</span>
                            </div>
                            <div>
                              <span className="text-gray-500">Completed:</span>
                              <span className="ml-1 font-medium text-green-600">{dept.completed_count}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="government-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-oag-primary" />
                    Task Completion Rate
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="completed" fill="#10B981" name="Completed" />
                      <Bar dataKey="pending" fill="#F59E0B" name="Pending" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="government-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-oag-primary" />
                    Officer Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="officers" fill="#8B5CF6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="government-card lg:col-span-2">
                <CardHeader>
                  <CardTitle>System Performance Summary</CardTitle>
                  <CardDescription>
                    Key performance indicators across the entire OAG system
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Activity Completion Rate</h4>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-600 h-2 rounded-full" 
                            style={{
                              width: `${systemStats.completed_tasks / (systemStats.completed_tasks + systemStats.pending_tasks) * 100 || 0}%`
                            }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">
                          {Math.round(systemStats.completed_tasks / (systemStats.completed_tasks + systemStats.pending_tasks) * 100 || 0)}%
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Average Activities per Officer</h4>
                      <div className="text-2xl font-bold text-oag-primary">
                        {systemStats.total_officers > 0 ? Math.round(systemStats.total_activities / systemStats.total_officers) : 0}
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h4 className="font-medium text-gray-900 mb-4">Top Performing Departments</h4>
                    <div className="space-y-3">
                      {departmentStats
                        .sort((a, b) => b.completed_count - a.completed_count)
                        .slice(0, 5)
                        .map((dept, index) => (
                          <div key={dept.id} className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-6 h-6 bg-oag-primary text-white rounded-full flex items-center justify-center text-xs font-bold">
                                {index + 1}
                              </div>
                              <span className="font-medium text-gray-900">{dept.name}</span>
                            </div>
                            <Badge className="bg-green-100 text-green-800 border-green-200">
                              {dept.completed_count} completed
                            </Badge>
                          </div>
                        ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="government-card">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-oag-primary" />
                    Recent Activity Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center p-6 text-gray-500">
                      <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">Activity trends will appear here as more data is collected</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}