import { redirect } from 'next/navigation'
import { supabase } from '@/lib/supabase'

export default async function DashboardPage() {
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect('/auth/login')
  }

  // Get user profile to determine category
  const { data: profile } = await supabase
    .from('users')
    .select('category')
    .eq('id', user.id)
    .single()

  if (!profile) {
    redirect('/auth/login')
  }

  // Redirect based on user category
  switch (profile.category) {
    case 'Officer':
      redirect('/dashboard/officer')
    case 'HOD':
    case 'CEO':
      redirect('/dashboard/hod')
    case 'AG':
      redirect('/dashboard/ag')
    default:
      redirect('/auth/login')
  }
}