import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co'
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'placeholder-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          county: string
          category: 'Officer' | 'HOD' | 'CEO' | 'AG'
          department_saga_id: string
          created_at: string
        }
        Insert: {
          id: string
          email: string
          full_name: string
          county: string
          category: 'Officer' | 'HOD' | 'CEO' | 'AG'
          department_saga_id: string
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          county?: string
          category?: 'Officer' | 'HOD' | 'CEO' | 'AG'
          department_saga_id?: string
          created_at?: string
        }
      }
      departments_sagas: {
        Row: {
          id: string
          name: string
          type: 'Department' | 'SAGA'
        }
        Insert: {
          id?: string
          name: string
          type: 'Department' | 'SAGA'
        }
        Update: {
          id?: string
          name?: string
          type?: 'Department' | 'SAGA'
        }
      }
      services: {
        Row: {
          id: string
          name: string
          description: string
          department_saga_id: string
        }
        Insert: {
          id?: string
          name: string
          description: string
          department_saga_id: string
        }
        Update: {
          id?: string
          name?: string
          description?: string
          department_saga_id?: string
        }
      }
      activities: {
        Row: {
          id: string
          user_id: string
          service_id: string
          description: string
          challenges: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          service_id: string
          description: string
          challenges?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          service_id?: string
          description?: string
          challenges?: string | null
          created_at?: string
        }
      }
      activity_status: {
        Row: {
          id: string
          activity_id: string
          pending_count: number
          completed_count: number
          updated_by: string
          created_at: string
        }
        Insert: {
          id?: string
          activity_id: string
          pending_count: number
          completed_count: number
          updated_by: string
          created_at?: string
        }
        Update: {
          id?: string
          activity_id?: string
          pending_count?: number
          completed_count?: number
          updated_by?: string
          created_at?: string
        }
      }
    }
  }
}