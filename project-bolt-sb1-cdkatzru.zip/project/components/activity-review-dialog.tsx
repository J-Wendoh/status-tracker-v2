"use client"

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Loader2, Save, Clock, CheckCircle, User, Calendar, Building } from 'lucide-react'
import { supabase } from '@/lib/supabase'

interface Activity {
  id: string
  description: string
  challenges: string | null
  created_at: string
  user: {
    full_name: string
    email: string
  }
  service: {
    name: string
    description: string
  }
  activity_status: {
    id: string
    pending_count: number
    completed_count: number
    updated_by: string
    created_at: string
  }[]
}

interface ActivityReviewDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  activity: Activity
  reviewerId: string
  onReviewSubmitted: () => void
}

export function ActivityReviewDialog({
  open,
  onOpenChange,
  activity,
  reviewerId,
  onReviewSubmitted
}: ActivityReviewDialogProps) {
  const [pendingCount, setPendingCount] = useState(0)
  const [completedCount, setCompletedCount] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const latestStatus = activity.activity_status[activity.activity_status.length - 1]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const { error: submitError } = await supabase
        .from('activity_status')
        .insert({
          activity_id: activity.id,
          pending_count: pendingCount,
          completed_count: completedCount,
          updated_by: reviewerId
        })

      if (submitError) throw submitError

      onReviewSubmitted()
    } catch (error: any) {
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="text-xl text-gray-900">Review Activity</DialogTitle>
          <DialogDescription>
            Update the status of this activity by setting pending and completed task counts
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Activity Details */}
          <div className="bg-gray-50 rounded-lg p-4 space-y-3">
            <div className="flex items-start gap-3">
              <User className="h-5 w-5 text-gray-600 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">{activity.user.full_name}</p>
                <p className="text-sm text-gray-600">{activity.user.email}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Building className="h-5 w-5 text-gray-600 mt-0.5" />
              <div>
                <p className="font-medium text-gray-900">{activity.service.name}</p>
                <p className="text-sm text-gray-600">{activity.service.description}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Calendar className="h-5 w-5 text-gray-600" />
              <p className="text-sm text-gray-600">
                Submitted on {new Date(activity.created_at).toLocaleDateString()} at{' '}
                {new Date(activity.created_at).toLocaleTimeString()}
              </p>
            </div>

            <div className="pt-2">
              <h4 className="font-medium text-gray-900 mb-2">Activity Description</h4>
              <p className="text-gray-700 bg-white p-3 rounded border">
                {activity.description}
              </p>
            </div>

            {activity.challenges && (
              <div>
                <h4 className="font-medium text-gray-900 mb-2">Challenges Reported</h4>
                <p className="text-gray-700 bg-white p-3 rounded border">
                  {activity.challenges}
                </p>
              </div>
            )}
          </div>

          {/* Current Status */}
          {latestStatus && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-900 mb-3">Current Status</h4>
              <div className="flex gap-4">
                <Badge variant="outline" className="text-orange-600 border-orange-600">
                  <Clock className="h-3 w-3 mr-1" />
                  {latestStatus.pending_count} pending
                </Badge>
                <Badge variant="outline" className="text-green-600 border-green-600">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  {latestStatus.completed_count} completed
                </Badge>
              </div>
              <p className="text-sm text-blue-700 mt-2">
                Last updated on {new Date(latestStatus.created_at).toLocaleDateString()}
              </p>
            </div>
          )}

          {/* Status Update Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pending" className="text-gray-700 font-medium flex items-center gap-2">
                  <Clock className="h-4 w-4 text-orange-600" />
                  Pending Tasks
                </Label>
                <Input
                  id="pending"
                  type="number"
                  min="0"
                  value={pendingCount}
                  onChange={(e) => setPendingCount(parseInt(e.target.value) || 0)}
                  className="border-gray-300 focus:border-orange-500 focus:ring-orange-500"
                  placeholder="0"
                  disabled={loading}
                />
                <p className="text-xs text-gray-600">
                  Number of tasks that are still in progress
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="completed" className="text-gray-700 font-medium flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  Completed Tasks
                </Label>
                <Input
                  id="completed"
                  type="number"
                  min="0"
                  value={completedCount}
                  onChange={(e) => setCompletedCount(parseInt(e.target.value) || 0)}
                  className="border-gray-300 focus:border-green-500 focus:ring-green-500"
                  placeholder="0"
                  disabled={loading}
                />
                <p className="text-xs text-gray-600">
                  Number of tasks that have been finished
                </p>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={loading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={loading}
                className="flex-1 bg-oag-primary hover:bg-oag-secondary text-white"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Update Status
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}