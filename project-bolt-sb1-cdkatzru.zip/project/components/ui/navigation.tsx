"use client"

import { useState } from 'react'
import Link from 'next/link'
import { useRouter, usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Menu, LogOut, Shield, Activity, Users, BarChart3, Settings } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { cn } from '@/lib/utils'

interface NavigationProps {
  user?: {
    id: string
    email: string
    full_name: string
    category: string
    department?: {
      name: string
      type: string
    }
  }
}

export function Navigation({ user }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false)
  const router = useRouter()
  const pathname = usePathname()

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/auth/login')
  }

  const getNavigationItems = () => {
    if (!user) return []

    const baseItems = [
      { href: '/dashboard', label: 'Dashboard', icon: BarChart3 },
    ]

    switch (user.category) {
      case 'Officer':
        return [
          ...baseItems,
          { href: '/dashboard/officer', label: 'My Activities', icon: Activity },
        ]
      case 'HOD':
      case 'CEO':
        return [
          ...baseItems,
          { href: '/dashboard/hod', label: 'Department', icon: Users },
          { href: '/dashboard/officer', label: 'My Activities', icon: Activity },
        ]
      case 'AG':
        return [
          ...baseItems,
          { href: '/dashboard/ag', label: 'System Overview', icon: Shield },
          { href: '/dashboard/hod', label: 'Department View', icon: Users },
          { href: '/dashboard/officer', label: 'Activities', icon: Activity },
        ]
      default:
        return baseItems
    }
  }

  const navigationItems = getNavigationItems()

  const NavItems = ({ mobile = false }: { mobile?: boolean }) => (
    <>
      {navigationItems.map((item) => {
        const Icon = item.icon
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={mobile ? () => setIsOpen(false) : undefined}
            className={cn(
              "flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
              pathname === item.href
                ? "bg-oag-primary/10 text-oag-primary border border-oag-primary/20"
                : "text-gray-600 hover:text-gray-900 hover:bg-gray-100",
              mobile && "w-full justify-start"
            )}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </Link>
        )
      })}
    </>
  )

  if (!user) return null

  return (
    <nav className="border-b border-gray-200 bg-white/95 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 oag-gradient rounded-md flex items-center justify-center">
              <Shield className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">OAG Kenya</h1>
              <p className="text-xs text-gray-500">Activity Tracking System</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            <NavItems />
          </div>

          {/* User Info & Actions */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-medium text-gray-900">{user.full_name}</p>
              <p className="text-xs text-gray-500">
                {user.category} • {user.department?.name}
              </p>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSignOut}
              className="text-gray-600 hover:text-red-600 hover:bg-red-50"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline ml-2">Sign Out</span>
            </Button>

            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col h-full">
                  <div className="flex items-center gap-3 pb-4 border-b">
                    <div className="w-10 h-10 oag-gradient rounded-md flex items-center justify-center">
                      <Shield className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h2 className="font-semibold text-gray-900">OAG Kenya</h2>
                      <p className="text-sm text-gray-500">Activity System</p>
                    </div>
                  </div>

                  <div className="py-4 border-b">
                    <p className="font-medium text-gray-900">{user.full_name}</p>
                    <p className="text-sm text-gray-500">{user.category}</p>
                    <p className="text-xs text-gray-500">{user.department?.name}</p>
                  </div>

                  <div className="flex-1 py-4 space-y-1">
                    <NavItems mobile />
                  </div>

                  <div className="border-t pt-4">
                    <Button
                      variant="ghost"
                      onClick={handleSignOut}
                      className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  )
}