"use client"

import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, Send, Activity } from 'lucide-react'
import { supabase } from '@/lib/supabase'

interface Service {
  id: string
  name: string
  description: string
}

interface ActivitySubmissionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  services: Service[]
  userId: string
  onSubmitted: () => void
}

export function ActivitySubmissionDialog({
  open,
  onOpenChange,
  services,
  userId,
  onSubmitted
}: ActivitySubmissionDialogProps) {
  const [formData, setFormData] = useState({
    serviceId: '',
    description: '',
    challenges: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const { error: submitError } = await supabase
        .from('activities')
        .insert({
          user_id: userId,
          service_id: formData.serviceId,
          description: formData.description,
          challenges: formData.challenges || null
        })

      if (submitError) throw submitError

      // Reset form
      setFormData({
        serviceId: '',
        description: '',
        challenges: ''
      })

      onSubmitted()
    } catch (error: any) {
      setError(error.message)
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-oag-primary/10 rounded-lg flex items-center justify-center">
              <Activity className="h-5 w-5 text-oag-primary" />
            </div>
            <div>
              <DialogTitle className="text-xl text-gray-900">Submit New Activity</DialogTitle>
              <DialogDescription>
                Log your daily activity with service details and any challenges encountered
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <Alert className="border-red-200 bg-red-50">
              <AlertDescription className="text-red-800">
                {error}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label className="text-gray-700 font-medium">Service</Label>
            <Select
              value={formData.serviceId}
              onValueChange={(value) => handleChange('serviceId', value)}
              disabled={loading}
            >
              <SelectTrigger className="border-gray-300 focus:border-oag-primary focus:ring-oag-primary">
                <SelectValue placeholder="Select the service this activity relates to" />
              </SelectTrigger>
              <SelectContent>
                {services.map((service) => (
                  <SelectItem key={service.id} value={service.id}>
                    <div>
                      <div className="font-medium">{service.name}</div>
                      <div className="text-sm text-gray-600">{service.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-700 font-medium">
              Activity Description *
            </Label>
            <Textarea
              id="description"
              placeholder="Describe the activity you performed, including key details, outcomes, and any significant actions taken..."
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="min-h-[120px] border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
              required
              disabled={loading}
            />
            <p className="text-xs text-gray-500">
              Be specific about what you did, who you worked with, and what was accomplished.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="challenges" className="text-gray-700 font-medium">
              Challenges Encountered (Optional)
            </Label>
            <Textarea
              id="challenges"
              placeholder="Describe any challenges, obstacles, or issues you faced during this activity..."
              value={formData.challenges}
              onChange={(e) => handleChange('challenges', e.target.value)}
              className="min-h-[80px] border-gray-300 focus:border-oag-primary focus:ring-oag-primary"
              disabled={loading}
            />
            <p className="text-xs text-gray-500">
              Include any problems that affected your work and how you addressed them.
            </p>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading || !formData.serviceId || !formData.description}
              className="flex-1 bg-oag-primary hover:bg-oag-secondary text-white"
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Submit Activity
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}